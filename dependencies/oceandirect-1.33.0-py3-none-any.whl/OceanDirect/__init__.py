from .OceanDirectAPI import *

__doc__ = OceanDirectAPI.__doc__
if hasattr(OceanDirectAPI, "__all__"):
    __all__ = OceanDirectAPI.__all__